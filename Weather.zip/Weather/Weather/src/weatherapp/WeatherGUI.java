package weatherapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class WeatherGUI {
    private JFrame frame;
    private JTextField cityInput;
    private JTextArea weatherOutput;
   
    public WeatherGUI() {
        frame = new JFrame("Weather App");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
       
        JPanel panel = new JPanel();
        panel.setLayout(new FlowLayout());
       
        JLabel label = new JLabel("Enter City:");
        cityInput = new JTextField(15);
        JButton getWeatherButton = new JButton("Get Weather");
       
        weatherOutput = new JTextArea();
        weatherOutput.setEditable(false);
        weatherOutput.setLineWrap(true);
        weatherOutput.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(weatherOutput);
       
        panel.add(label);
        panel.add(cityInput);
        panel.add(getWeatherButton);
       
        frame.add(panel, BorderLayout.NORTH);
        frame.add(scrollPane, BorderLayout.CENTER);
       
        getWeatherButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String location = cityInput.getText().trim();
                if (!location.isEmpty()) {
                    fetchWeather(location);
                } else {
                    weatherOutput.setText("Please enter a city name.");
                }
            }
        });
       
        frame.setVisible(true);
    }
   
    private void fetchWeather(String location) {
        String key = "1516fe41c920442babd110027200105&q=" + location;
        String url = "http://api.weatherapi.com/v1/current.json?key=" + key;
       
        try {
            URL uh = new URL(url);
            BufferedReader bf = new BufferedReader(new InputStreamReader(uh.openStream()));
            String json = bf.readLine();
           
            String[] data = json.split(",");
            Map<String, String> map = new HashMap<>();
           
            for (String datum : data) {
                if (Pattern.compile(".region*").matcher(datum).find()) {
                    map.put("Region", datum.split(":")[1]);
                } else if (Pattern.compile(".country*").matcher(datum).find()) {
                    map.put("Country", datum.split(":")[1]);
                } else if (Pattern.compile(".localtime[^a-z]*").matcher(datum).find()) {
                    map.put("Localtime", datum.split(":")[1]);
                } else if (Pattern.compile(".temp_c.").matcher(datum).find()) {
                    map.put("Temperature (Celsius)", datum.split(":")[1]);
                } else if (Pattern.compile(".*text*").matcher(datum).find()) {
                    map.put("Condition", datum.split(":")[1]);
                }
            }
           
            StringBuilder output = new StringBuilder();
            for (Map.Entry<String, String> entry : map.entrySet()) {
                output.append(entry.getKey()).append(" : ").append(entry.getValue()).append("\n");
            }
           
            weatherOutput.setText(output.toString());
        } catch (Exception e) {
            weatherOutput.setText("Error fetching weather data.");
        }
    }
   
    public static void main(String[] args) {
        new WeatherGUI();
    }
}
